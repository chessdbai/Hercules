import * as cdk from '@aws-cdk/core';
import { HerculesAccount } from '../accounts';
interface MachineLearningStackProps {
    account: HerculesAccount;
    groupName: string;
}
export declare class MachineLearningStack extends cdk.Stack {
    constructor(app: cdk.App, name: string, props: MachineLearningStackProps);
}
export {};
