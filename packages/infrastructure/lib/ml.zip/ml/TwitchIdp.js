"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.TwitchIdp = void 0;
const user_pool_idp_base_1 = require("@aws-cdk/aws-cognito/lib/user-pool-idps/private/user-pool-idp-base");
const cognito = require("@aws-cdk/aws-cognito");
class TwitchIdp extends user_pool_idp_base_1.UserPoolIdentityProviderBase {
    /**
     *
     */
    constructor(scope, id, props) {
        super(scope, id, props);
        const resource = new cognito.CfnUserPoolIdentityProvider(this, 'Resource', {
            userPoolId: props.userPool.userPoolId,
            providerName: 'Twitch',
            providerType: 'OIDC',
            providerDetails: {
                client_id: props.clientId,
                client_secret: props.clientSecret,
                authorize_scopes: props.scopes.join(' '),
                attributes_request_method: 'GET',
                oidc_issuer: 'https://id.twitch.tv/oauth2',
                authorize_url: 'https://id.twitch.tv/oauth2/authorize',
                token_url: 'https://id.twitch.tv/oauth2/token',
                attributes_url: 'https://id.twitch.tv/oauth2/userinfo',
                jwks_uri: 'https://id.twitch.tv/oauth2/keys'
            },
            attributeMapping: super.configureAttributeMapping(),
        });
        this.providerName = super.getResourceNameAttribute(resource.ref);
    }
}
exports.TwitchIdp = TwitchIdp;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiVHdpdGNoSWRwLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiVHdpdGNoSWRwLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7OztBQUNBLDJHQUFrSDtBQUNsSCxnREFBZ0Q7QUFXaEQsTUFBYSxTQUFVLFNBQVEsaURBQTRCO0lBS3pEOztPQUVHO0lBQ0gsWUFBWSxLQUFnQixFQUFFLEVBQVUsRUFBRSxLQUFxQjtRQUM3RCxLQUFLLENBQUMsS0FBSyxFQUFFLEVBQUUsRUFBRSxLQUFLLENBQUMsQ0FBQztRQUV4QixNQUFNLFFBQVEsR0FBRyxJQUFJLE9BQU8sQ0FBQywyQkFBMkIsQ0FBQyxJQUFJLEVBQUUsVUFBVSxFQUFFO1lBQ3pFLFVBQVUsRUFBRSxLQUFLLENBQUMsUUFBUSxDQUFDLFVBQVU7WUFDckMsWUFBWSxFQUFFLFFBQVE7WUFDdEIsWUFBWSxFQUFFLE1BQU07WUFDcEIsZUFBZSxFQUFFO2dCQUNiLFNBQVMsRUFBRSxLQUFLLENBQUMsUUFBUTtnQkFDekIsYUFBYSxFQUFFLEtBQUssQ0FBQyxZQUFZO2dCQUNqQyxnQkFBZ0IsRUFBRSxLQUFLLENBQUMsTUFBTyxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUM7Z0JBQ3pDLHlCQUF5QixFQUFFLEtBQUs7Z0JBQ2hDLFdBQVcsRUFBRSw2QkFBNkI7Z0JBQzFDLGFBQWEsRUFBRSx1Q0FBdUM7Z0JBQ3RELFNBQVMsRUFBRSxtQ0FBbUM7Z0JBQzlDLGNBQWMsRUFBRSxzQ0FBc0M7Z0JBQ3RELFFBQVEsRUFBRSxrQ0FBa0M7YUFDL0M7WUFDRCxnQkFBZ0IsRUFBRSxLQUFLLENBQUMseUJBQXlCLEVBQUU7U0FDdEQsQ0FBQyxDQUFDO1FBQ0gsSUFBSSxDQUFDLFlBQVksR0FBRyxLQUFLLENBQUMsd0JBQXdCLENBQUMsUUFBUSxDQUFDLEdBQUcsQ0FBQyxDQUFDO0lBQ2pFLENBQUM7Q0FDRjtBQTlCRCw4QkE4QkMiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBDb25zdHJ1Y3QgfSBmcm9tICdjb25zdHJ1Y3RzJztcbmltcG9ydCB7IFVzZXJQb29sSWRlbnRpdHlQcm92aWRlckJhc2UgfSBmcm9tICdAYXdzLWNkay9hd3MtY29nbml0by9saWIvdXNlci1wb29sLWlkcHMvcHJpdmF0ZS91c2VyLXBvb2wtaWRwLWJhc2UnO1xuaW1wb3J0ICogYXMgY29nbml0byBmcm9tICdAYXdzLWNkay9hd3MtY29nbml0byc7XG5cbi8qKlxuICogUHJvcGVydGllcyB0byBpbml0aWFsaXplIFR3aXRjaElkcC5cbiAqL1xuZXhwb3J0IGludGVyZmFjZSBUd2l0Y2hJZHBQcm9wcyBleHRlbmRzIGNvZ25pdG8uVXNlclBvb2xJZGVudGl0eVByb3ZpZGVyUHJvcHMge1xuICByZWFkb25seSBjbGllbnRJZDogc3RyaW5nO1xuICByZWFkb25seSBjbGllbnRTZWNyZXQ6IHN0cmluZztcbiAgcmVhZG9ubHkgc2NvcGVzPzogc3RyaW5nW107XG59XG5cbmV4cG9ydCBjbGFzcyBUd2l0Y2hJZHAgZXh0ZW5kcyBVc2VyUG9vbElkZW50aXR5UHJvdmlkZXJCYXNlIHtcbiAgLyoqXG4gICAqIFRoZSBwcmltYXJ5IGlkZW50aWZpZXIgb2YgdGhpcyBpZGVudGl0eSBwcm92aWRlci5cbiAgICovXG4gIHJlYWRvbmx5IHByb3ZpZGVyTmFtZTogc3RyaW5nO1xuICAvKipcbiAgICpcbiAgICovXG4gIGNvbnN0cnVjdG9yKHNjb3BlOiBDb25zdHJ1Y3QsIGlkOiBzdHJpbmcsIHByb3BzOiBUd2l0Y2hJZHBQcm9wcykge1xuICAgIHN1cGVyKHNjb3BlLCBpZCwgcHJvcHMpO1xuXG4gICAgY29uc3QgcmVzb3VyY2UgPSBuZXcgY29nbml0by5DZm5Vc2VyUG9vbElkZW50aXR5UHJvdmlkZXIodGhpcywgJ1Jlc291cmNlJywge1xuICAgICAgdXNlclBvb2xJZDogcHJvcHMudXNlclBvb2wudXNlclBvb2xJZCxcbiAgICAgIHByb3ZpZGVyTmFtZTogJ1R3aXRjaCcsXG4gICAgICBwcm92aWRlclR5cGU6ICdPSURDJyxcbiAgICAgIHByb3ZpZGVyRGV0YWlsczoge1xuICAgICAgICAgIGNsaWVudF9pZDogcHJvcHMuY2xpZW50SWQsXG4gICAgICAgICAgY2xpZW50X3NlY3JldDogcHJvcHMuY2xpZW50U2VjcmV0LFxuICAgICAgICAgIGF1dGhvcml6ZV9zY29wZXM6IHByb3BzLnNjb3BlcyEuam9pbignICcpLFxuICAgICAgICAgIGF0dHJpYnV0ZXNfcmVxdWVzdF9tZXRob2Q6ICdHRVQnLFxuICAgICAgICAgIG9pZGNfaXNzdWVyOiAnaHR0cHM6Ly9pZC50d2l0Y2gudHYvb2F1dGgyJyxcbiAgICAgICAgICBhdXRob3JpemVfdXJsOiAnaHR0cHM6Ly9pZC50d2l0Y2gudHYvb2F1dGgyL2F1dGhvcml6ZScsXG4gICAgICAgICAgdG9rZW5fdXJsOiAnaHR0cHM6Ly9pZC50d2l0Y2gudHYvb2F1dGgyL3Rva2VuJyxcbiAgICAgICAgICBhdHRyaWJ1dGVzX3VybDogJ2h0dHBzOi8vaWQudHdpdGNoLnR2L29hdXRoMi91c2VyaW5mbycsXG4gICAgICAgICAgandrc191cmk6ICdodHRwczovL2lkLnR3aXRjaC50di9vYXV0aDIva2V5cydcbiAgICAgIH0sXG4gICAgICBhdHRyaWJ1dGVNYXBwaW5nOiBzdXBlci5jb25maWd1cmVBdHRyaWJ1dGVNYXBwaW5nKCksXG4gIH0pO1xuICB0aGlzLnByb3ZpZGVyTmFtZSA9IHN1cGVyLmdldFJlc291cmNlTmFtZUF0dHJpYnV0ZShyZXNvdXJjZS5yZWYpO1xuICB9XG59XG4iXX0=