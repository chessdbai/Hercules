"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.MachineLearningStack = void 0;
const cdk = require("@aws-cdk/core");
const iam = require("@aws-cdk/aws-iam");
const cognito = require("@aws-cdk/aws-cognito");
const lambda = require("@aws-cdk/aws-lambda");
const sagemaker = require("@aws-cdk/aws-sagemaker");
const s3 = require("@aws-cdk/aws-s3");
const s3deploy = require("@aws-cdk/aws-s3-deployment");
const path = require("path");
const ml_auth_1 = require("./ml-auth");
class MachineLearningStack extends cdk.Stack {
    constructor(app, name, props) {
        super(app, name, {
            env: {
                account: props.account.accountId,
                region: props.account.region
            }
        });
        const auth = new ml_auth_1.Auth(this, 'Auth', {
            account: props.account
        });
        const sagemakerClient = new cognito.UserPoolClient(this, 'SagemakerClient', {
            generateSecret: true,
            userPool: auth.userPool,
            userPoolClientName: 'SagemakerClient',
            authFlows: {
                userPassword: true,
                custom: true,
                userSrp: true
            }
        });
        const preLabellingTask = new lambda.Function(this, 'PreLambda', {
            code: lambda.Code.fromAsset(path.join(__dirname, 'pretask')),
            handler: 'index.handler',
            runtime: lambda.Runtime.PYTHON_3_6,
        });
        const postLabellingTask = new lambda.Function(this, 'PostLambda', {
            code: lambda.Code.fromAsset(path.join(__dirname, 'posttask')),
            handler: 'index.handler',
            runtime: lambda.Runtime.PYTHON_3_6,
        });
        preLabellingTask.addPermission('SageMakerInvokePre', {
            action: 'lambda:InvokeFunction',
            principal: new iam.AccountPrincipal(cdk.Aws.ACCOUNT_ID)
        });
        postLabellingTask.addPermission('SageMakerInvokePost', {
            action: 'lambda:InvokeFunction',
            principal: new iam.AccountPrincipal(cdk.Aws.ACCOUNT_ID)
        });
        const workforce = new sagemaker.CfnWorkteam(this, 'WorkTeam', {
            description: 'Private labelling workforce.',
            workteamName: 'tacticLabellingTeam',
            memberDefinitions: [
                {
                    cognitoMemberDefinition: {
                        cognitoUserPool: auth.userPool.userPoolId,
                        cognitoUserGroup: props.groupName,
                        cognitoClientId: sagemakerClient.userPoolClientId
                    }
                }
            ]
        });
        const datasetBucket = new s3.Bucket(this, 'DatasetsBucket', {});
        const deployment = new s3deploy.BucketDeployment(this, 'BucketDeployment', {
            sources: [
                s3deploy.Source.asset(path.resolve(path.join(__dirname, './datasets')))
            ],
            destinationBucket: datasetBucket
        });
    }
}
exports.MachineLearningStack = MachineLearningStack;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoibWwtc3RhY2suanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyJtbC1zdGFjay50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7QUFBQSxxQ0FBcUM7QUFDckMsd0NBQXdDO0FBQ3hDLGdEQUFnRDtBQUNoRCw4Q0FBOEM7QUFDOUMsb0RBQW9EO0FBQ3BELHNDQUFzQztBQUN0Qyx1REFBdUQ7QUFDdkQsNkJBQTZCO0FBSTdCLHVDQUFpQztBQU9qQyxNQUFhLG9CQUFxQixTQUFRLEdBQUcsQ0FBQyxLQUFLO0lBRWpELFlBQVksR0FBWSxFQUFFLElBQVksRUFBRSxLQUFnQztRQUN0RSxLQUFLLENBQUMsR0FBRyxFQUFFLElBQUksRUFBRTtZQUNmLEdBQUcsRUFBRTtnQkFDSCxPQUFPLEVBQUUsS0FBSyxDQUFDLE9BQU8sQ0FBQyxTQUFTO2dCQUNoQyxNQUFNLEVBQUUsS0FBSyxDQUFDLE9BQU8sQ0FBQyxNQUFNO2FBQzdCO1NBQ0YsQ0FBQyxDQUFDO1FBRUgsTUFBTSxJQUFJLEdBQUcsSUFBSSxjQUFJLENBQUMsSUFBSSxFQUFFLE1BQU0sRUFBRTtZQUNsQyxPQUFPLEVBQUUsS0FBSyxDQUFDLE9BQU87U0FDdkIsQ0FBQyxDQUFDO1FBRUgsTUFBTSxlQUFlLEdBQUcsSUFBSSxPQUFPLENBQUMsY0FBYyxDQUFDLElBQUksRUFBRSxpQkFBaUIsRUFBRTtZQUMxRSxjQUFjLEVBQUUsSUFBSTtZQUNwQixRQUFRLEVBQUUsSUFBSSxDQUFDLFFBQVE7WUFDdkIsa0JBQWtCLEVBQUUsaUJBQWlCO1lBQ3JDLFNBQVMsRUFBRTtnQkFDVCxZQUFZLEVBQUUsSUFBSTtnQkFDbEIsTUFBTSxFQUFFLElBQUk7Z0JBQ1osT0FBTyxFQUFFLElBQUk7YUFDZDtTQUNGLENBQUMsQ0FBQztRQUVILE1BQU0sZ0JBQWdCLEdBQUcsSUFBSSxNQUFNLENBQUMsUUFBUSxDQUFDLElBQUksRUFBRSxXQUFXLEVBQUU7WUFDOUQsSUFBSSxFQUFFLE1BQU0sQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsU0FBUyxFQUFFLFNBQVMsQ0FBQyxDQUFDO1lBQzVELE9BQU8sRUFBRSxlQUFlO1lBQ3hCLE9BQU8sRUFBRSxNQUFNLENBQUMsT0FBTyxDQUFDLFVBQVU7U0FDbkMsQ0FBQyxDQUFDO1FBQ0gsTUFBTSxpQkFBaUIsR0FBRyxJQUFJLE1BQU0sQ0FBQyxRQUFRLENBQUMsSUFBSSxFQUFFLFlBQVksRUFBRTtZQUNoRSxJQUFJLEVBQUUsTUFBTSxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxTQUFTLEVBQUUsVUFBVSxDQUFDLENBQUM7WUFDN0QsT0FBTyxFQUFFLGVBQWU7WUFDeEIsT0FBTyxFQUFFLE1BQU0sQ0FBQyxPQUFPLENBQUMsVUFBVTtTQUNuQyxDQUFDLENBQUM7UUFFSCxnQkFBZ0IsQ0FBQyxhQUFhLENBQUMsb0JBQW9CLEVBQUU7WUFDbkQsTUFBTSxFQUFFLHVCQUF1QjtZQUMvQixTQUFTLEVBQUUsSUFBSSxHQUFHLENBQUMsZ0JBQWdCLENBQUMsR0FBRyxDQUFDLEdBQUcsQ0FBQyxVQUFVLENBQUM7U0FDeEQsQ0FBQyxDQUFBO1FBQ0YsaUJBQWlCLENBQUMsYUFBYSxDQUFDLHFCQUFxQixFQUFFO1lBQ3JELE1BQU0sRUFBRSx1QkFBdUI7WUFDL0IsU0FBUyxFQUFFLElBQUksR0FBRyxDQUFDLGdCQUFnQixDQUFDLEdBQUcsQ0FBQyxHQUFHLENBQUMsVUFBVSxDQUFDO1NBQ3hELENBQUMsQ0FBQTtRQUVGLE1BQU0sU0FBUyxHQUFHLElBQUksU0FBUyxDQUFDLFdBQVcsQ0FBQyxJQUFJLEVBQUUsVUFBVSxFQUFFO1lBQzVELFdBQVcsRUFBRSw4QkFBOEI7WUFDM0MsWUFBWSxFQUFFLHFCQUFxQjtZQUNuQyxpQkFBaUIsRUFBRTtnQkFDakI7b0JBQ0UsdUJBQXVCLEVBQUU7d0JBQ3ZCLGVBQWUsRUFBRSxJQUFJLENBQUMsUUFBUSxDQUFDLFVBQVU7d0JBQ3pDLGdCQUFnQixFQUFFLEtBQUssQ0FBQyxTQUFTO3dCQUNqQyxlQUFlLEVBQUUsZUFBZSxDQUFDLGdCQUFnQjtxQkFDbEQ7aUJBQ0Y7YUFDRjtTQUNGLENBQUMsQ0FBQztRQUVILE1BQU0sYUFBYSxHQUFHLElBQUksRUFBRSxDQUFDLE1BQU0sQ0FBQyxJQUFJLEVBQUUsZ0JBQWdCLEVBQUUsRUFFM0QsQ0FBQyxDQUFDO1FBQ0gsTUFBTSxVQUFVLEdBQUcsSUFBSSxRQUFRLENBQUMsZ0JBQWdCLENBQUMsSUFBSSxFQUFFLGtCQUFrQixFQUFFO1lBQ3pFLE9BQU8sRUFBRTtnQkFDUCxRQUFRLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsU0FBUyxFQUFFLFlBQVksQ0FBQyxDQUFDLENBQUM7YUFDeEU7WUFDRCxpQkFBaUIsRUFBRSxhQUFhO1NBQ2pDLENBQUMsQ0FBQztJQUNMLENBQUM7Q0FDRjtBQXJFRCxvREFxRUMiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgKiBhcyBjZGsgZnJvbSAnQGF3cy1jZGsvY29yZSc7XG5pbXBvcnQgKiBhcyBpYW0gZnJvbSAnQGF3cy1jZGsvYXdzLWlhbSc7XG5pbXBvcnQgKiBhcyBjb2duaXRvIGZyb20gJ0Bhd3MtY2RrL2F3cy1jb2duaXRvJztcbmltcG9ydCAqIGFzIGxhbWJkYSBmcm9tICdAYXdzLWNkay9hd3MtbGFtYmRhJztcbmltcG9ydCAqIGFzIHNhZ2VtYWtlciBmcm9tICdAYXdzLWNkay9hd3Mtc2FnZW1ha2VyJztcbmltcG9ydCAqIGFzIHMzIGZyb20gJ0Bhd3MtY2RrL2F3cy1zMyc7XG5pbXBvcnQgKiBhcyBzM2RlcGxveSBmcm9tICdAYXdzLWNkay9hd3MtczMtZGVwbG95bWVudCc7XG5pbXBvcnQgKiBhcyBwYXRoIGZyb20gJ3BhdGgnO1xuaW1wb3J0ICogYXMgZnMgZnJvbSAnZnMnO1xuXG5pbXBvcnQgeyBIZXJjdWxlc0FjY291bnQgfSBmcm9tICcuLi9hY2NvdW50cyc7XG5pbXBvcnQgeyBBdXRoIH0gZnJvbSAnLi9tbC1hdXRoJztcblxuaW50ZXJmYWNlIE1hY2hpbmVMZWFybmluZ1N0YWNrUHJvcHMge1xuICBhY2NvdW50OiBIZXJjdWxlc0FjY291bnQsXG4gIGdyb3VwTmFtZTogc3RyaW5nXG59XG5cbmV4cG9ydCBjbGFzcyBNYWNoaW5lTGVhcm5pbmdTdGFjayBleHRlbmRzIGNkay5TdGFjayB7XG5cbiAgY29uc3RydWN0b3IoYXBwOiBjZGsuQXBwLCBuYW1lOiBzdHJpbmcsIHByb3BzOiBNYWNoaW5lTGVhcm5pbmdTdGFja1Byb3BzKSB7XG4gICAgc3VwZXIoYXBwLCBuYW1lLCB7XG4gICAgICBlbnY6IHtcbiAgICAgICAgYWNjb3VudDogcHJvcHMuYWNjb3VudC5hY2NvdW50SWQsXG4gICAgICAgIHJlZ2lvbjogcHJvcHMuYWNjb3VudC5yZWdpb25cbiAgICAgIH1cbiAgICB9KTtcblxuICAgIGNvbnN0IGF1dGggPSBuZXcgQXV0aCh0aGlzLCAnQXV0aCcsIHtcbiAgICAgIGFjY291bnQ6IHByb3BzLmFjY291bnRcbiAgICB9KTtcblxuICAgIGNvbnN0IHNhZ2VtYWtlckNsaWVudCA9IG5ldyBjb2duaXRvLlVzZXJQb29sQ2xpZW50KHRoaXMsICdTYWdlbWFrZXJDbGllbnQnLCB7XG4gICAgICBnZW5lcmF0ZVNlY3JldDogdHJ1ZSxcbiAgICAgIHVzZXJQb29sOiBhdXRoLnVzZXJQb29sLFxuICAgICAgdXNlclBvb2xDbGllbnROYW1lOiAnU2FnZW1ha2VyQ2xpZW50JyxcbiAgICAgIGF1dGhGbG93czoge1xuICAgICAgICB1c2VyUGFzc3dvcmQ6IHRydWUsXG4gICAgICAgIGN1c3RvbTogdHJ1ZSxcbiAgICAgICAgdXNlclNycDogdHJ1ZVxuICAgICAgfVxuICAgIH0pO1xuXG4gICAgY29uc3QgcHJlTGFiZWxsaW5nVGFzayA9IG5ldyBsYW1iZGEuRnVuY3Rpb24odGhpcywgJ1ByZUxhbWJkYScsIHtcbiAgICAgIGNvZGU6IGxhbWJkYS5Db2RlLmZyb21Bc3NldChwYXRoLmpvaW4oX19kaXJuYW1lLCAncHJldGFzaycpKSxcbiAgICAgIGhhbmRsZXI6ICdpbmRleC5oYW5kbGVyJyxcbiAgICAgIHJ1bnRpbWU6IGxhbWJkYS5SdW50aW1lLlBZVEhPTl8zXzYsXG4gICAgfSk7XG4gICAgY29uc3QgcG9zdExhYmVsbGluZ1Rhc2sgPSBuZXcgbGFtYmRhLkZ1bmN0aW9uKHRoaXMsICdQb3N0TGFtYmRhJywge1xuICAgICAgY29kZTogbGFtYmRhLkNvZGUuZnJvbUFzc2V0KHBhdGguam9pbihfX2Rpcm5hbWUsICdwb3N0dGFzaycpKSxcbiAgICAgIGhhbmRsZXI6ICdpbmRleC5oYW5kbGVyJyxcbiAgICAgIHJ1bnRpbWU6IGxhbWJkYS5SdW50aW1lLlBZVEhPTl8zXzYsXG4gICAgfSk7XG5cbiAgICBwcmVMYWJlbGxpbmdUYXNrLmFkZFBlcm1pc3Npb24oJ1NhZ2VNYWtlckludm9rZVByZScsIHtcbiAgICAgIGFjdGlvbjogJ2xhbWJkYTpJbnZva2VGdW5jdGlvbicsXG4gICAgICBwcmluY2lwYWw6IG5ldyBpYW0uQWNjb3VudFByaW5jaXBhbChjZGsuQXdzLkFDQ09VTlRfSUQpXG4gICAgfSlcbiAgICBwb3N0TGFiZWxsaW5nVGFzay5hZGRQZXJtaXNzaW9uKCdTYWdlTWFrZXJJbnZva2VQb3N0Jywge1xuICAgICAgYWN0aW9uOiAnbGFtYmRhOkludm9rZUZ1bmN0aW9uJyxcbiAgICAgIHByaW5jaXBhbDogbmV3IGlhbS5BY2NvdW50UHJpbmNpcGFsKGNkay5Bd3MuQUNDT1VOVF9JRClcbiAgICB9KVxuICAgIFxuICAgIGNvbnN0IHdvcmtmb3JjZSA9IG5ldyBzYWdlbWFrZXIuQ2ZuV29ya3RlYW0odGhpcywgJ1dvcmtUZWFtJywge1xuICAgICAgZGVzY3JpcHRpb246ICdQcml2YXRlIGxhYmVsbGluZyB3b3JrZm9yY2UuJyxcbiAgICAgIHdvcmt0ZWFtTmFtZTogJ3RhY3RpY0xhYmVsbGluZ1RlYW0nLFxuICAgICAgbWVtYmVyRGVmaW5pdGlvbnM6IFtcbiAgICAgICAge1xuICAgICAgICAgIGNvZ25pdG9NZW1iZXJEZWZpbml0aW9uOiB7XG4gICAgICAgICAgICBjb2duaXRvVXNlclBvb2w6IGF1dGgudXNlclBvb2wudXNlclBvb2xJZCxcbiAgICAgICAgICAgIGNvZ25pdG9Vc2VyR3JvdXA6IHByb3BzLmdyb3VwTmFtZSxcbiAgICAgICAgICAgIGNvZ25pdG9DbGllbnRJZDogc2FnZW1ha2VyQ2xpZW50LnVzZXJQb29sQ2xpZW50SWRcbiAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgIF1cbiAgICB9KTtcblxuICAgIGNvbnN0IGRhdGFzZXRCdWNrZXQgPSBuZXcgczMuQnVja2V0KHRoaXMsICdEYXRhc2V0c0J1Y2tldCcsIHtcblxuICAgIH0pO1xuICAgIGNvbnN0IGRlcGxveW1lbnQgPSBuZXcgczNkZXBsb3kuQnVja2V0RGVwbG95bWVudCh0aGlzLCAnQnVja2V0RGVwbG95bWVudCcsIHtcbiAgICAgIHNvdXJjZXM6IFtcbiAgICAgICAgczNkZXBsb3kuU291cmNlLmFzc2V0KHBhdGgucmVzb2x2ZShwYXRoLmpvaW4oX19kaXJuYW1lLCAnLi9kYXRhc2V0cycpKSlcbiAgICAgIF0sXG4gICAgICBkZXN0aW5hdGlvbkJ1Y2tldDogZGF0YXNldEJ1Y2tldFxuICAgIH0pO1xuICB9XG59Il19