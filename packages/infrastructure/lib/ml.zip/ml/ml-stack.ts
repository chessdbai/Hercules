import * as cdk from '@aws-cdk/core';
import * as iam from '@aws-cdk/aws-iam';
import * as cognito from '@aws-cdk/aws-cognito';
import * as lambda from '@aws-cdk/aws-lambda';
import * as sagemaker from '@aws-cdk/aws-sagemaker';
import * as s3 from '@aws-cdk/aws-s3';
import * as s3deploy from '@aws-cdk/aws-s3-deployment';
import * as path from 'path';
import * as fs from 'fs';

import { HerculesAccount } from '../accounts';
import { Auth } from './ml-auth';

interface MachineLearningStackProps {
  account: HerculesAccount,
  groupName: string
}

export class MachineLearningStack extends cdk.Stack {

  constructor(app: cdk.App, name: string, props: MachineLearningStackProps) {
    super(app, name, {
      env: {
        account: props.account.accountId,
        region: props.account.region
      }
    });

    const auth = new Auth(this, 'Auth', {
      account: props.account
    });

    const sagemakerClient = new cognito.UserPoolClient(this, 'SagemakerClient', {
      generateSecret: true,
      userPool: auth.userPool,
      userPoolClientName: 'SagemakerClient',
      authFlows: {
        userPassword: true,
        custom: true,
        userSrp: true
      }
    });

    const preLabellingTask = new lambda.Function(this, 'PreLambda', {
      code: lambda.Code.fromAsset(path.join(__dirname, 'pretask')),
      handler: 'index.handler',
      runtime: lambda.Runtime.PYTHON_3_6,
    });
    const postLabellingTask = new lambda.Function(this, 'PostLambda', {
      code: lambda.Code.fromAsset(path.join(__dirname, 'posttask')),
      handler: 'index.handler',
      runtime: lambda.Runtime.PYTHON_3_6,
    });

    preLabellingTask.addPermission('SageMakerInvokePre', {
      action: 'lambda:InvokeFunction',
      principal: new iam.AccountPrincipal(cdk.Aws.ACCOUNT_ID)
    })
    postLabellingTask.addPermission('SageMakerInvokePost', {
      action: 'lambda:InvokeFunction',
      principal: new iam.AccountPrincipal(cdk.Aws.ACCOUNT_ID)
    })
    
    const workforce = new sagemaker.CfnWorkteam(this, 'WorkTeam', {
      description: 'Private labelling workforce.',
      workteamName: 'tacticLabellingTeam',
      memberDefinitions: [
        {
          cognitoMemberDefinition: {
            cognitoUserPool: auth.userPool.userPoolId,
            cognitoUserGroup: props.groupName,
            cognitoClientId: sagemakerClient.userPoolClientId
          }
        }
      ]
    });

    const datasetBucket = new s3.Bucket(this, 'DatasetsBucket', {

    });
    const deployment = new s3deploy.BucketDeployment(this, 'BucketDeployment', {
      sources: [
        s3deploy.Source.asset(path.resolve(path.join(__dirname, './datasets')))
      ],
      destinationBucket: datasetBucket
    });
  }
}