import json
import boto3
from urllib.parse import quote

def handler(event, context):
  print(event)

  fen = event['dataObject']['source']
  url_safe_fen = quote(fen)

  work = {
    'taskInput': {
      'taskObject': 'http://www.fen-to-image.com/image/' + url_safe_fen,
      'metadata': {
        'fen': fen
      }
    },
    'isHumanAnnotationRequired': 'true'
  } 

  print('Work:')
  print(json.dumps(work))

  return work