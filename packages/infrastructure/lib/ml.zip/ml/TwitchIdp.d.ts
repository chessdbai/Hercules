import { Construct } from 'constructs';
import { UserPoolIdentityProviderBase } from '@aws-cdk/aws-cognito/lib/user-pool-idps/private/user-pool-idp-base';
import * as cognito from '@aws-cdk/aws-cognito';
/**
 * Properties to initialize TwitchIdp.
 */
export interface TwitchIdpProps extends cognito.UserPoolIdentityProviderProps {
    readonly clientId: string;
    readonly clientSecret: string;
    readonly scopes?: string[];
}
export declare class TwitchIdp extends UserPoolIdentityProviderBase {
    /**
     * The primary identifier of this identity provider.
     */
    readonly providerName: string;
    /**
     *
     */
    constructor(scope: Construct, id: string, props: TwitchIdpProps);
}
